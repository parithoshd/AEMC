import { useState } from "react";
import "./styles.css";

// Components
import Description from "./Description";
import Content from "./Content";
import Notes from "./Notes";
import Test from "./Test";

export default function App() {
  const [activeTab, setActiveTab] = useState("Description");

  return (
    <div className="App">
      {/* Navigation */}
      <div className="tab-group">
        <ul>
          <li onClick={() => setActiveTab("Description")}>Description</li>
          <li onClick={() => setActiveTab("Content")}>Contents</li>
          <li onClick={() => setActiveTab("Notes")}>Notes</li>
          <li onClick={() => setActiveTab("Test")}>Test</li>
        </ul>
      </div>

      {/* All the Components */}
      <div className="component-group">
        {activeTab === "Description" && <Description />}
        {activeTab === "Content" && <Content />}
        {activeTab === "Notes" && <Notes />}
        {activeTab === "Test" && <Test />}
      </div>
    </div>
  );
}
