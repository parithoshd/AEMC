import React from "react";

const Description = () => {
  return <div>Description Page</div>;
};

export default Description;
