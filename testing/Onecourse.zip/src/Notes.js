import React from "react";

const Notes = () => {
  return <div>Notes Page</div>;
};

export default Notes;
