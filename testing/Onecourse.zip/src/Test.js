import React from "react";

const Test = () => {
  return <div>Test Page</div>;
};

export default Test;
