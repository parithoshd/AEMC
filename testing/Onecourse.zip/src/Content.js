import React from "react";

const Content = () => {
  return <div>Content Page</div>;
};

export default Content;
